# def vowels(s : str)->int:
#     c=0
#     for i in s:
#         if i in 'aeiouAEIOU':
#             c+=1
#     return c

# s=input()
# print(vowels(s))

s='sjgsa'
s1='b'
if s<s1:
    print("True")
else:
    print("False")